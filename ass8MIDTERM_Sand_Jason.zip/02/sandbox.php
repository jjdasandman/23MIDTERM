<?php
	
	include 'lib/ReadPlainText.php';
	include 'lib/ReadCSV.php';
	include 'lib/ReadJSON.php';
	//echo $textData = ReadPlainText('data/overview.txt');
	//$var = ReadPlainText('');     <-- template
	$name = ReadPlainText('data/name.txt','NaturaTech');
	$overview = ReadPlainText('data/overview.txt'); 
	$awards = readJSON('data/awards.JSON');	
	
	

	if (isset($awards['awards']) && is_array($awards['awards'])) {
    // Loop through the awards array and generate HTML for each award
    foreach ($awards['awards'] as $award) {
        $year = $award['year'];
        $awardName = $award['award'];
        $source = $award['source'];
        echo $year; ?> <br> <?php
        echo $awardName; ?> <br> <?php
        echo $source; ?> <br> <?php
    }
}else {
        // Handle the case where keys are missing in the data
        echo "Incomplete data for an award.<br><br>";
		echo '<pre>';
		print_r($awards);
		echo '</pre>';
		
		} 

?>
<a href="index.php">
	<button type="button" class="#">go back</button>
</a>
<?php
// Include any necessary files and functions
include '../../lib/ReadCSV.php';

// Retrieve data from your data source (e.g., CSV file)
$csvFilePath = '../../data/products.csv';
$products = ReadCSV($csvFilePath);

// Check if the product ID is provided in the query parameters
if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    // Find the product with the specified ID
    $product = null;
    foreach ($products as $p) {
        if ($p[0] == $productId) {
            $product = $p;
            break;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Product Details</title>
</head>
<body>
    <h1>Product Details</h1>

    <?php if ($product) { ?>
        <h2>Product Name: <?= $product[0] ?></h2>
        <p>Description: <?= $product[1] ?></p>
        <p>Application: <?= $product[2] ?></p>
		<p>icon: <?= $product[3] ?></p>

        <!-- Edit and Delete buttons -->
        <form method="post" action="edit.php?id=<?= $product[0] ?>">
            <button type="submit">Edit</button>
        </form>

        <form method="post" action="delete.php?id=<?= $product[0] ?>">
            <button type="submit">Delete</button>
        </form>
    <?php } else { ?>
        <p>Product not foundddddd.</p>
    <?php } ?>

    <p><a href="index.php">Back to Product List</a></p>
</body>
</html>
<?php 
echo "you landed on the create page";


// Include any necessary files and functions
include '../../lib/ReadPlainText.php';
include '../../lib/ReadCSV.php';
include '../../lib/ReadJSON.php';
$data = ReadCSV('../../data/navbar.csv');
if (!empty($data) && isset($data[0])) {
		// Skip the first row (header)
		array_shift($data);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process and validate the form data
	$section = $_POST['section'];
	$link = $_POST['link'];
	
	// Validate the "link" input
	if (empty($link) || substr($link, 0, 1) !== '#') {
		// Handle the case where the "link" input is empty or doesn't start with a "#"
		echo 'The "link" field must not be empty and must start with "#".';
		exit; // Terminate the script
	}
    // Add the new item to your data source (e.g., CSV file)
	
	// Specify the path to your CSV file
	$csvFilePath = '../../data/navbar.csv';

	// Prepare the data for the new item as an array
	$newItem = [$section, $link];
	
	// Ensure that the CSV file ends with a newline character
	$fileContents = file_get_contents($csvFilePath);
	if (substr($fileContents, -1) !== "\n") {
		$fileContents .= "\n";
		file_put_contents($csvFilePath, $fileContents);
	}

	// Open the CSV file in append mode
	$file = fopen($csvFilePath, 'a');

	// Lock the file for writing
	if (flock($file, LOCK_EX)) {
		// Write the new item to the CSV file
		fputcsv($file, $newItem);

		// Release the lock
		flock($file, LOCK_UN);

		// Close the file
		fclose($file);
	} else {
		// Handle the case where the file could not be locked (e.g., concurrent access)
		echo 'Unable to add the new item at this time. Please try again later.';
		exit; // Terminate the script
	}
	
    // Redirect the user to the edit page for the newly created item
    header('Location: edit.php?section=' . urlencode($section)); 
    exit; // Terminate the script
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create New Item</title>
</head>
<body>
    <h1>Create New Item</h1>
    <form method="POST" action="">
        <!-- Form fields for creating a new item -->
        <label for="section">Item Name:</label>
        <input type="text" name="section" id="section" required>

        <label for="link">Item Link:</label>
        <input type="text" name="link" id="link" required>

        <input type="submit" value="Create Item">
    </form>
    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>
<!-- <p><a href="index.php">
	<button type="button" class="#">go back</button>
</a></p> -->
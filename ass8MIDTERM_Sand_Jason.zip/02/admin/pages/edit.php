<?php
// Include any necessary files and functions
include '../../lib/ReadCSV.php';

// Initialize the $items array as an empty array
$items = [];
// Update the item in your data source 
        $csvFilePath = '../../data/navbar.csv';

// Load the items from the CSV file        
$items = ReadCSV($csvFilePath);

// Check if a specific item is requested (e.g., based on query parameters)
if (isset($_GET['section'])) {
    $requestedSection = $_GET['section'];
    $existingLink = '';
    // Load the items from the CSV file
    $items = ReadCSV($csvFilePath);

    // Check if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Process and validate the form data
        $updatedSection = $_POST['section'];
        $updatedLink = $_POST['link'];

        // Find and update the requested item
        foreach ($items as &$item) {
            if ($item[0] === $requestedSection) {
				
                $item[0] = $updatedSection; // Update the section name
				echo "updated section: ".$updatedSection."<br>";
                $item[1] = $updatedLink;    // Update the link
				echo "updated link: ".$updatedLink."<br>";
                break;
            }
        }

        // Save the updated data back to the CSV file
        $csvFile = fopen($csvFilePath, 'w');
    if ($csvFile) {
        if (flock($csvFile, LOCK_EX)) {
			echo '<pre>'; // Wrap in <pre> tags to format the output nicely
			print_r($items); // Print the array
			echo '</pre>';
            foreach ($items as $a) {
                fputcsv($csvFile, $a);
            }
            flock($csvFile, LOCK_UN);
            fclose($csvFile);
			header('Location: index.php'); 
			exit;
        } else {
            echo 'Unable to save the changes at this time. Please try again later.';
        }
    }
    }
}
/*
echo '<pre>'; // Wrap in <pre> tags to format the output nicely
print_r($items); // Print the array
echo '</pre>';
?><p><a href="index.php"><button type="button" class="#">return to index</button></p><?php
*/
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Item</title>
</head>
<body>
    <h1>Edit Item</h1>

    <?php
	
	
    // Check if the requested item is found and display the form for editing
    if (isset($requestedSection) && $requestedSection) {
        // Display the form for editing the item with pre-filled values
		echo "in first if<br>";
        echo '<pre>'; 
		print_r($items); // Print the array
		echo '</pre>';
	foreach ($items as $b) {
		//echo "in foreach<br>";
		//echo "Requested Section: $requestedSection<br>";
		//echo "CSV Item Section: " . $item[0] . "<br>";
		if ($b[0] === $requestedSection) {
			$existingLink = $b[1];
			echo "Match Found - Existing Link: $existingLink<br>";
			break;
		}
	}
		
		
    ?>
        <form method="POST" action="">
            <!-- Form fields for editing the item -->
            <label for="section">Item Name:</label>
            <input type="text" name="section" id="section" value="<?php echo $requestedSection; ?>" required>

            <label for="link">Item Link:</label>
            <!-- You can populate the "link" field with the existing link value here -->
            <input type="text" name="link" id="link" value="<?php echo $existingLink; ?>" required>

            <input type="submit" value="Save Changes">
        </form>
    <?php
	
    } else {
        // Handle the case where the requested item is not found
        echo 'Item not found.';
    }
	
    ?>

    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>

<!--// Redirect the user to the edit page for the newly created item
    header('Location: index.php'); 
    exit; // Terminate the script -->
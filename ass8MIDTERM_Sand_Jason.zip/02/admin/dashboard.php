<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Admin Dashboard</h1>
	<h1>Welcome, <?= $username ?>!</h1>
    <a href="logout.php">Logout</a>
    <table border="1">
        <thead>
            <tr>
                <th>Subfolder</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Awards</td>
                <td><a href="awards/index.php">View Details</a></td>
            </tr>
            <tr>
                <td>Contacts</td>
                <td><a href="contacts/index.php">View Details</a></td>
            </tr>
            <tr>
                <td>Pages</td>
                <td><a href="pages/index.php">View Details</a></td>
            </tr>
            <tr>
                <td>Products</td>
                <td><a href="products/index.php">View Details</a></td>
            </tr>
            <tr>
                <td>Team</td>
                <td><a href="team/index.php">View Details</a></td>
            </tr>
        </tbody>
    </table>
	<p><a href="../index.php">
	<button type="button" class="#">return to homepage</button>
	</a></p>
</body>
</html>
<?php
// Include any necessary files and functions
include '../../lib/ReadCSV.php';

// Initialize the $items array as an empty array
$items = [];

// Update the item in your data source
$csvFilePath = '../../data/team.csv'; // Update to the correct CSV file name

if (file_exists($csvFilePath)) {
    $items = ReadCSV($csvFilePath);
} else {
    echo "File does not exist: $csvFilePath";
}

// Load the items from the CSV file

// Check if a specific item is requested (e.g., based on query parameters)
if (isset($_GET['section'])) {
    $requestedSection = $_GET['section'];
    $existingData = [];

    // Load the items from the CSV file
    $items = ReadCSV($csvFilePath);

    // Check if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Process and validate the form data
        //var_dump($_POST); // Debug: Dump the data being submitted

        $updatedName = $_POST['name'];
        $updatedTitle = $_POST['title'];
        $updatedBackground = $_POST['background'];
        $updatedPic = $_POST['pic'];
        //var_dump($updatedName, $updatedTitle, $updatedBackground, $updatedPic); // Debug: Dump the updated data

        // Find and update the requested item
        foreach ($items as &$item) {
            if ($item[0] === $requestedSection) {
                $item[0] = $updatedName;
                $item[1] = $updatedTitle;
                $item[2] = $updatedBackground;
                $item[3] = $updatedPic;
                break;
            }
        }

        // Save the updated data back to the CSV file
        $csvFile = fopen($csvFilePath, 'w');
        if ($csvFile) {
            if (flock($csvFile, LOCK_EX)) {
                foreach ($items as $a) {
                    fputcsv($csvFile, $a);
                }
                flock($csvFile, LOCK_UN);
                fclose($csvFile);
                header('Location: index.php');
                exit;
            } else {
                echo 'Unable to save the changes at this time. Please try again later.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Team Member</title>
</head>
<body>
    <h1>Edit Team Member</h1>

    <?php
    // Check if the requested item is found and display the form for editing
    if (isset($requestedSection) && $requestedSection) {
        // Display the form for editing the item with pre-filled values
        echo '<pre>';
        foreach ($items as $b) {
            if ($b[0] === $requestedSection) {
                $existingData = $b;
                break;
            }
        }
        echo '</pre>';
    ?>
        <form method="POST" action="">
            <!-- Form fields for editing the item -->
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" value="<?php echo $existingData[0]; ?>" required>

            <label for="title">Title:</label>
            <input type="text" name="title" id="title" value="<?php echo $existingData[1]; ?>" required>

            <label for="background">Background:</label>
            <textarea name="background" id="background" rows="4" cols="50" required><?php echo $existingData[2]; ?></textarea>

            <label for="pic">Picture URL:</label>
            <input type="text" name="pic" id="pic" value="<?php echo $existingData[3]; ?>" required>

            <input type="submit" value="Save Changes">
        </form>
    <?php
    } else {
        // Handle the case where the requested item is not found
        echo 'Team member not found.';
    }
    ?>

    <p><a href="index.php">Back to Team List</a></p>
</body>
</html>
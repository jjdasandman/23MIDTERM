<?php
/* AWARDS DELETE */

include '../../lib/ReadJSON.php';

// Check if the item should be deleted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
    $year = $_GET['year'];
    $award_name = $_GET['award'];

    // Read the awards data from awards.json
    $awardsJson = file_get_contents('../../data/awards.json');
    $awards = json_decode($awardsJson, true);

    if (isset($awards['awards']) && is_array($awards['awards'])) {
        foreach ($awards['awards'] as $key => $award) {
            if ($award['year'] === $year && $award['award'] === $award_name) {
                // Remove the item
                unset($awards['awards'][$key]);
                $awards['awards'] = array_values($awards['awards']); // Reindex the array

                // Save the updated data back to awards.json
                $awardsJson = json_encode($awards, JSON_PRETTY_PRINT);
                file_put_contents('../../data/awards.json', $awardsJson);

                // Redirect the user to the index page
                header('Location: index.php');
                exit;
            }
        }
    }
}

// If the user hasn't confirmed the deletion, show the confirmation form
?>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Award</title>
</head>
<body>
    <h1>Delete Award</h1>
    <p>Are you sure you want to delete this award?</p>
    <form method="post" action="">
        <input type="hidden" name="confirm" value="yes">
        <input type="submit" value="Yes, Delete">
    </form>
    <p><a href="index.php">Back to Awards List</a></p>
</body>
</html>
<?php
 function readPlainText($filename) {
    // Read plain text file and return its content
    $content = file_get_contents($filename);
    return $content;
}
?>